package com.example.githubusers.model

data class GithubUsers(
    var users: List<User>
)